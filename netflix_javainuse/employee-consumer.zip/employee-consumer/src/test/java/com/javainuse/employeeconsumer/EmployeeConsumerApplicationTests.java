package com.javainuse.employeeconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
