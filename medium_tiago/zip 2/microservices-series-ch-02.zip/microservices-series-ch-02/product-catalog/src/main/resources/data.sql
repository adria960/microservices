INSERT INTO PRODUCTS(ID, NAME, BRAND, DESCRIPTION, PRICE) VALUES (801, 'laptop','new brand', 'Super fast laptop', 2000.0);
INSERT INTO PRODUCTS(ID, NAME, BRAND, DESCRIPTION, PRICE) VALUES (802, 'smartphone','no brand', 'black cellphone', 1500.0);
INSERT INTO PRODUCTS(ID, NAME, BRAND, DESCRIPTION, PRICE) VALUES (803, 'video game','atari', 'old school video game', 1800.0);
INSERT INTO PRODUCTS(ID, NAME, BRAND, DESCRIPTION, PRICE) VALUES (804, 'smart tv','any brand', 'Big smart tv full of apps', 2000.0);
INSERT INTO PRODUCTS(ID, NAME, BRAND, DESCRIPTION, PRICE) VALUES (805, 'mouse','new new brand', 'just a mouse - not the animal :=P', 100.0);
