package com.tiagoamp.shoppingcart;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingCartApplicationTests {

	@Disabled
	@Test
	void contextLoads() {
	}

}
