# microservices-series

This is the source code of the microservices developed to demonstrate the concepts of this kind of architecture in my blog posts at Medium.

This branch contains the source code of part(chapter) 1:

[Part I: Project setup, REST communication and Service Discovery](https://tiagoamp.medium.com/microservices-with-java-part-1-f5fe79bf43aa) - branch ch-01
