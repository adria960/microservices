INSERT INTO USERS(ID, NAME, EMAIL, BIRTHDATE, ADDRESS) VALUES (901, 'Isaac Newton', 'isaac@newton.com', '1643-01-04', 'gravity street - England');
INSERT INTO USERS(ID, NAME, EMAIL, BIRTHDATE, ADDRESS) VALUES (902, 'Nikola Tesla', 'nicola@tesla.com', '1853-07-10', 'electric street - England');
INSERT INTO USERS(ID, NAME, EMAIL, BIRTHDATE, ADDRESS) VALUES (903, 'John von Neumann', 'john@neumann.com', '1903-12-28', 'logic street - EUA');
INSERT INTO USERS(ID, NAME, EMAIL, BIRTHDATE, ADDRESS) VALUES (904, 'Stephen Hawking', 'stephen@hawking.com', '1942-01-08', 'universe street - England');