package com.tiagoamp.userinfo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserInfoApplicationTests {

	@Test
	void contextLoads() {
	}

}
