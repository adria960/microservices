package com.techefx.microservices.springcloudapigatewayservice.techefxspringcloudapigatewayservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechefxSpringCloudApiGatewayServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
